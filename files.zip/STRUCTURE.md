# 📁 PROJECT STRUCTURE

```
jarvis-assistant/
│
├── 📄 main.py                    # Main entry point (API server)
├── 📄 run_cli.py                 # CLI mode entry point
├── 📄 test_setup.py              # Setup verification script
├── 📄 requirements.txt           # Python dependencies
├── 📄 .env.example               # Environment template
├── 📄 .gitignore                 # Git ignore rules
├── 📄 README.md                  # Full documentation
├── 📄 QUICKSTART.md              # Quick start guide
│
├── 📁 api/                       # REST API & WebSocket
│   ├── __init__.py
│   └── server.py                 # FastAPI server
│
├── 📁 config/                    # Configuration
│   ├── __init__.py
│   └── settings.py               # Settings management
│
├── 📁 core/                      # Core logic
│   ├── __init__.py
│   └── assistant.py              # Main orchestrator
│
├── 📁 services/                  # Service modules
│   ├── __init__.py
│   ├── elevenlabs_service.py    # ElevenLabs integration
│   └── audio_service.py          # Audio processing
│
├── 📁 utils/                     # Utilities
│   ├── __init__.py
│   └── logger.py                 # Logging system
│
└── 📁 logs/                      # Log files (auto-created)
    └── assistant.log
```

## File Descriptions

### Entry Points
- **main.py**: Starts FastAPI server with full API
- **run_cli.py**: Simple CLI mode without API
- **test_setup.py**: Verifies installation

### Core System
- **core/assistant.py**: Brain of the system, orchestrates everything
- **services/elevenlabs_service.py**: WebSocket connection to ElevenLabs
- **services/audio_service.py**: Microphone input & speaker output

### API Layer
- **api/server.py**: REST endpoints + WebSocket for monitoring

### Configuration
- **config/settings.py**: Loads environment variables
- **.env**: Your API keys (create from .env.example)

### Utilities
- **utils/logger.py**: Color-coded logging with JSON export
