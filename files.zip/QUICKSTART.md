# 🚀 QUICK START GUIDE

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

## Step 2: Configure Environment

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Edit `.env` and add your ElevenLabs credentials:
```
ELEVEN_LABS_API_KEY=sk_xxxxxxxxxxxxx
ELEVEN_LABS_AGENT_ID=xxxxxxxxxxxxx
```

**How to get these:**
- Go to https://elevenlabs.io
- Sign up/login
- Go to Profile → API Keys → Copy your key
- Go to Conversational AI → Create/Select Agent → Copy Agent ID

## Step 3: Test Your Setup

```bash
python test_setup.py
```

This will verify:
- ✅ Python version
- ✅ Dependencies installed
- ✅ Environment variables set
- ✅ Audio devices available

## Step 4: Run the Assistant

**Option A: Full API Server (Recommended)**
```bash
python main.py
```
Then visit: http://localhost:8000/docs

**Option B: Simple CLI**
```bash
python run_cli.py
```

## Step 5: Control via API

**Start the assistant:**
```bash
curl -X POST http://localhost:8000/assistant/start
```

**Check status:**
```bash
curl http://localhost:8000/assistant/status
```

**Stop the assistant:**
```bash
curl -X POST http://localhost:8000/assistant/stop
```

## Troubleshooting

**"ModuleNotFoundError"**
→ Run: `pip install -r requirements.txt`

**"No audio devices found"**
→ Check microphone/speaker permissions
→ Make sure a microphone is connected

**"Connection failed to ElevenLabs"**
→ Verify API key and Agent ID in .env
→ Check internet connection

## What's Next?

Once running, you can:
1. Talk to your assistant through the microphone
2. Monitor conversations via API
3. Add custom features in `services/` directory
4. Build a web UI to interact with the API

Read `README.md` for full documentation!
