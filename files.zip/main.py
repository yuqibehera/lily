#!/usr/bin/env python3
"""
Jarvis Voice Assistant - Main Entry Point
Run this file to start the voice assistant
"""
import asyncio
import sys
import signal
from api.server import run_server
from utils.logger import setup_logger

logger = setup_logger(__name__)


def signal_handler(sig, frame):
    """Handle Ctrl+C gracefully"""
    logger.info("\nShutting down Voice Assistant...")
    sys.exit(0)


def main():
    """Main function to start the voice assistant"""
    
    # ASCII Art Logo
    logo = """
    ╔═══════════════════════════════════════════════════╗
    ║                                                   ║
    ║         JARVIS VOICE ASSISTANT v1.0              ║
    ║         Powered by ElevenLabs                    ║
    ║                                                   ║
    ╚═══════════════════════════════════════════════════╝
    """
    
    print(logo)
    logger.info("Initializing Jarvis Voice Assistant...")
    
    # Register signal handler for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Run the FastAPI server
        logger.info("Starting API server...")
        run_server()
        
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
