#!/usr/bin/env python3
"""
Simple CLI Interface for Voice Assistant
Direct command-line interface without API server
"""
import asyncio
import sys
import signal
from core import VoiceAssistantCore
from utils.logger import setup_logger

logger = setup_logger(__name__)

# Global assistant instance
assistant = None
running = True


def signal_handler(sig, frame):
    """Handle Ctrl+C gracefully"""
    global running
    running = False
    logger.info("\nShutting down...")


async def main():
    """Main CLI function"""
    global assistant, running
    
    # ASCII Art
    print("""
    ╔═══════════════════════════════════════════════════╗
    ║         JARVIS VOICE ASSISTANT - CLI MODE        ║
    ╚═══════════════════════════════════════════════════╝
    """)
    
    # Register signal handler
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        # Initialize assistant
        logger.info("Initializing Voice Assistant...")
        assistant = VoiceAssistantCore()
        
        # Start assistant
        logger.info("Starting Voice Assistant...")
        await assistant.start()
        
        print("\n✅ Voice Assistant is active! Speak to interact.")
        print("Press Ctrl+C to stop.\n")
        
        # Keep running until interrupted
        while running and assistant.is_running:
            await asyncio.sleep(0.1)
        
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.error(f"Error: {e}")
    finally:
        # Cleanup
        if assistant:
            logger.info("Stopping assistant...")
            await assistant.stop()
        logger.info("Goodbye!")


if __name__ == "__main__":
    asyncio.run(main())
