# 🤖 Jarvis Voice Assistant

A production-ready, high-performance voice assistant powered by ElevenLabs Conversational AI. Built with a modular architecture designed to evolve into a full Jarvis-like AI system.

## 🎯 Features

- **Real-time Voice Interaction**: Full-duplex conversation with ElevenLabs
- **Advanced Audio Processing**: Professional-grade audio input/output handling
- **Modular Architecture**: Easily extensible for new capabilities
- **REST API**: Control and monitor via HTTP endpoints
- **WebSocket Support**: Real-time monitoring and updates
- **Conversation History**: Track and analyze conversations
- **Production-Ready**: Proper logging, error handling, and async architecture

## 📁 Project Structure

```
jarvis-assistant/
├── api/
│   ├── __init__.py
│   └── server.py              # FastAPI server with REST + WebSocket
├── config/
│   ├── __init__.py
│   └── settings.py            # Configuration management
├── core/
│   ├── __init__.py
│   └── assistant.py           # Main orchestration logic
├── services/
│   ├── __init__.py
│   ├── elevenlabs_service.py  # ElevenLabs integration
│   └── audio_service.py       # Audio processing
├── utils/
│   ├── __init__.py
│   └── logger.py              # Advanced logging system
├── logs/                      # Log files (created automatically)
├── main.py                    # Main entry point (API mode)
├── run_cli.py                 # Simple CLI mode
├── requirements.txt           # Python dependencies
└── .env                       # Environment variables (create this)
```

## 🚀 Quick Start

### 1. Prerequisites

- Python 3.9+
- ElevenLabs account with API key
- ElevenLabs Conversational AI agent created
- Microphone and speakers

### 2. Installation

```bash
# Clone or download the project
cd jarvis-assistant

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Configuration

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# Required
ELEVEN_LABS_API_KEY=your_api_key_here
ELEVEN_LABS_AGENT_ID=your_agent_id_here

# Optional - for future features
OPENAI_API_KEY=optional_openai_key
ANTHROPIC_API_KEY=optional_anthropic_key

# Server Configuration
HOST=0.0.0.0
PORT=8000
DEBUG=True
```

**Getting your ElevenLabs credentials:**
1. Go to [ElevenLabs](https://elevenlabs.io)
2. Navigate to your profile → API Keys
3. Create/copy your API key
4. Go to Conversational AI section
5. Create an agent and copy its Agent ID

### 4. Run the Assistant

**Option A: Full API Server Mode (Recommended)**

```bash
python main.py
```

This starts a FastAPI server with REST API and WebSocket support.

Access the API at: `http://localhost:8000`

**Option B: Simple CLI Mode**

```bash
python run_cli.py
```

This starts the assistant directly without the API server.

## 🎮 Usage

### API Endpoints

Once the server is running, you can control the assistant via HTTP:

**Start the assistant:**
```bash
curl -X POST http://localhost:8000/assistant/start
```

**Stop the assistant:**
```bash
curl -X POST http://localhost:8000/assistant/stop
```

**Check status:**
```bash
curl http://localhost:8000/assistant/status
```

**Send text command:**
```bash
curl -X POST http://localhost:8000/assistant/command \
  -H "Content-Type: application/json" \
  -d '{"text": "What is the weather?"}'
```

**Get conversation history:**
```bash
curl http://localhost:8000/conversation/history
```

### API Documentation

Visit `http://localhost:8000/docs` for interactive API documentation (Swagger UI).

### WebSocket Monitoring

Connect to `ws://localhost:8000/ws/monitor` to receive real-time status updates.

## 🔧 Architecture

### Core Components

1. **VoiceAssistantCore** (`core/assistant.py`)
   - Main orchestrator that manages all services
   - Handles conversation flow and state
   - Coordinates between audio and ElevenLabs

2. **ElevenLabsVoiceAssistant** (`services/elevenlabs_service.py`)
   - WebSocket connection to ElevenLabs
   - Audio streaming and text transcription
   - Conversation management

3. **AudioProcessor** (`services/audio_service.py`)
   - Microphone input capture
   - Audio playback
   - Voice activity detection

4. **FastAPI Server** (`api/server.py`)
   - REST API endpoints
   - WebSocket for monitoring
   - Health checks and status

### Data Flow

```
Microphone → AudioProcessor → ElevenLabsService → ElevenLabs API
                                                         ↓
User Speakers ← AudioProcessor ← ElevenLabsService ← Response
```

## 🛠️ Extending to Jarvis

This foundation is designed to grow. Here's how to add features:

### 1. Add Smart Home Control

```python
# services/smart_home_service.py
class SmartHomeService:
    async def control_lights(self, action: str):
        # Integrate with Philips Hue, etc.
        pass
```

### 2. Add Calendar Integration

```python
# services/calendar_service.py
class CalendarService:
    async def get_schedule(self):
        # Google Calendar API integration
        pass
```

### 3. Add Custom Skills

Create new services in `services/` directory and register them in `core/assistant.py`.

### 4. Add Vision (Multimodal)

```python
# services/vision_service.py
class VisionService:
    async def analyze_image(self, image_data):
        # Computer vision integration
        pass
```

## 📊 Logging

Logs are stored in `logs/assistant.log` with JSON formatting for easy parsing.

Console logs are color-coded:
- 🟢 INFO: Green
- 🟡 WARNING: Yellow
- 🔴 ERROR: Red
- 🔵 DEBUG: Cyan

## 🐛 Troubleshooting

**Issue: No audio input**
- Check microphone permissions
- Verify microphone is selected as default device
- Run: `python -m pyaudio` to test audio setup

**Issue: Connection failed to ElevenLabs**
- Verify API key and Agent ID are correct
- Check internet connection
- Ensure agent is active in ElevenLabs dashboard

**Issue: Audio playback choppy**
- Adjust `CHUNK_SIZE` in settings
- Check system CPU usage
- Try lower sample rate

## 🔐 Security Notes

- Never commit `.env` file to version control
- Keep API keys secure
- Use environment variables for production
- Consider rate limiting for production deployments

## 📈 Performance Tips

1. **Optimize Audio Buffer**: Adjust `CHUNK_SIZE` based on your latency requirements
2. **Voice Activity Detection**: Enable VAD to reduce unnecessary API calls
3. **Async Processing**: All I/O operations are async for maximum performance
4. **Connection Pooling**: WebSocket connection is persistent

## 🚀 Next Steps

1. **Add custom wake word detection** (e.g., "Hey Jarvis")
2. **Implement context awareness** (remember previous conversations)
3. **Add function calling** (execute actions based on commands)
4. **Create web UI** (React/Vue frontend)
5. **Add database** (PostgreSQL for persistence)
6. **Implement plugins system** (load skills dynamically)

## 📝 License

MIT License - feel free to use and modify

## 🤝 Contributing

This is your personal project, but the architecture supports:
- Adding new services
- Creating plugins
- Extending API endpoints
- Adding new integrations

## 💡 Tips

- Start simple, test each component
- Use the CLI mode for debugging
- Monitor logs for issues
- Gradually add features
- Keep modules independent

---

**Ready to build Jarvis?** Start the assistant and begin talking! 🎤
